# Atlas · Tantivy Local Search

Flask UI for the existing SQLite database and Tantivy index. The app **does not build or modify the source database or index**. It discovers the table and column names from SQLite metadata at runtime, so the UI uses the real schema names rather than the old hard-coded customer-field names. It opens SQLite using `mode=ro` and uses the existing index at `~/Desktop/users_search_index`.

## Default paths
- SQLite: `~/Desktop/users_merged.db`
- Tantivy index: `~/Desktop/users_search_index`
- Local web UI: `http://127.0.0.1:8080`

## Run

```bash
unzip atlas_tantivy_local_search.zip
cd atlas_tantivy_local_search
chmod +x run.sh
./run.sh
```

The script reuses `/tmp/tantivy-search-env` if present; otherwise it creates a project virtual environment. It installs the Flask/Tantivy dependencies but **does not rebuild the index**.


## Optional custom paths

```bash
USERS_DB=/path/to/users_merged.db USERS_SEARCH_INDEX=/path/to/users_search_index ./run.sh
```

## Search behavior
- Search is across Tantivy fields `C2` through `C13`.
- Column/table names are detected dynamically from the SQLite schema and displayed as their actual names.
- Search results are ranked by Tantivy and complete rows are retrieved by the primary key.
- The source SQLite file is read-only.
- For searches returning more than 5,000 hits, pagination is limited to the first 5,000 ranked matches to avoid unbounded memory use.
- Empty search browses the SQLite table by primary-key order. Very high browse pages use SQLite `OFFSET`, which may take longer.

## Local access and privacy

The default host is `127.0.0.1`, not `0.0.0.0`. Keep it local. To access from another computer, use an SSH port forward instead of exposing the service publicly. The database contains sensitive information; do not publish this service without authentication and access controls.

## Access from another computer (SSH tunnel)

Keep the Flask host on `127.0.0.1`. From your own computer, open an SSH tunnel with `ssh -L 8080:127.0.0.1:8080 root@YOUR_VM`, then browse to `http://127.0.0.1:8080` locally.
