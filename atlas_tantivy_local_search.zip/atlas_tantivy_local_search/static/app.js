const $ = id => document.getElementById(id);
let page = 1, pages = 1, debounceTimer = null, currentController = null, seq = 0, cols = [], pk = "";
const esc = v => String(v ?? "—").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const fa = n => Number(n || 0).toLocaleString("fa-IR");
function setStatus(text, good=false){$("dbStatus").textContent=text;$("dbStatus").style.color=good?"var(--green)":"var(--muted)";}
function emptyRow(text){return `<tr><td class="empty" colspan="${Math.max(cols.length+1,1)}">${esc(text)}</td></tr>`;}
function makeTableHead(){
  $("thead").innerHTML=`<tr>${cols.map(c=>`<th title="${esc(c)}">${esc(c)}</th>`).join("")}<th>جزئیات</th></tr>`;
}
function renderRows(rows){
  if(!rows.length){$("results").innerHTML=emptyRow("نتیجه‌ای پیدا نشد.");$("mobileResults").innerHTML='<div class="empty">نتیجه‌ای پیدا نشد.</div>';return;}
  $("results").innerHTML=rows.map(row=>`<tr>${cols.map(c=>`<td title="${esc(row[c])}">${esc(row[c])}</td>`).join("")}<td><button class="detail-btn" data-id="${esc(row[pk])}">جزئیات</button></td></tr>`).join("");
  $("mobileResults").innerHTML=rows.map(row=>`<article class="mobile-card"><div class="mobile-card-head"><strong>${esc(row[pk])}</strong><small>رکورد</small></div><div class="mobile-card-grid">${cols.slice(0,4).map(c=>`<span>${esc(c)}<b>${esc(row[c])}</b></span>`).join("")}</div><button class="detail-btn" data-id="${esc(row[pk])}" style="margin-top:12px">نمایش جزئیات</button></article>`).join("");
}
function params(){return new URLSearchParams({q:$('query').value.trim(),page:String(page),per_page:$('perPage').value});}
async function load(){
  if(currentController)currentController.abort();
  currentController=new AbortController();const request=++seq;
  $('results').innerHTML=emptyRow("در حال جستجو…");
  try{
    const resp=await fetch('/api/search?'+params(),{signal:currentController.signal});
    const data=await resp.json();if(request!==seq)return;if(!data.ok)throw Error(data.error||"خطای جستجو");
    pages=data.pages||1;$('resultCount').textContent=fa(data.total);$('caption').textContent=data.query?`${fa(data.total)} نتیجه برای «${data.query}»${data.capped?` · نمایش حداکثر ${fa(data.max_search_hits)} نتیجه اول`:''}`:`نمایش رکوردها از دیتابیس`;
    $('pageInfo').textContent=`صفحه ${fa(page)} از ${fa(Math.max(1,pages))}`;$('prevBtn').disabled=page<=1;$('nextBtn').disabled=page>=pages;
    renderRows(data.rows);
  }catch(e){if(e.name==='AbortError')return;$('results').innerHTML=emptyRow(e.message);$('mobileResults').innerHTML='';}
}
async function health(){
  try{const res=await fetch('/api/health');const data=await res.json();if(!data.ok)throw Error(data.error);
    if(!data.index_ready)throw Error(data.error||"ایندکس در دسترس نیست");
    cols=data.columns;pk=data.primary_key;makeTableHead();$('totalCount').textContent=fa(data.count);setStatus("آماده",true);load();
  }catch(e){setStatus("خطا");$('results').innerHTML=emptyRow(e.message);toast(e.message);}
}
function doSearch(){page=1;load();}
function toast(s){$('toast').textContent=s;$('toast').classList.add('show');setTimeout(()=>$('toast').classList.remove('show'),2600);}
$('searchBtn').onclick=doSearch;
$('query').addEventListener('keydown',e=>{if(e.key==='Enter')doSearch();});
$('query').addEventListener('input',()=>{clearTimeout(debounceTimer);debounceTimer=setTimeout(doSearch,300);});
$('perPage').onchange=doSearch;
$('prevBtn').onclick=()=>{if(page>1){page--;load();}};
$('nextBtn').onclick=()=>{if(page<pages){page++;load();}};
$('clearBtn').onclick=()=>{$('query').value='';doSearch();$('query').focus();};
document.addEventListener('click',async e=>{
  const btn=e.target.closest('[data-id]');if(!btn)return;
  try{const res=await fetch('/api/row/'+encodeURIComponent(btn.dataset.id));const data=await res.json();if(!data.ok)throw Error(data.error);
    $('detailBody').innerHTML='<div class="detail-grid">'+data.columns.map(c=>`<div class="detail-item"><small>${esc(c)}</small><b>${esc(data.row[c])}</b></div>`).join('')+'</div>';
    $('modal').classList.add('open');
  }catch(err){toast(err.message);}
});
$('modalClose').onclick=()=>$('modal').classList.remove('open');$('modal').onclick=e=>{if(e.target===$('modal'))$('modal').classList.remove('open');};
$('themeBtn').onclick=()=>document.body.classList.toggle('light');
document.addEventListener('keydown',e=>{if(e.key==='/'&&!['INPUT','TEXTAREA'].includes(document.activeElement.tagName)){e.preventDefault();$('query').focus();}if(e.key==='Escape')$('modal').classList.remove('open');});
health();
