#!/usr/bin/env python3
"""Atlas local Tantivy search UI. SQLite and Tantivy are opened read-only."""
import os, sqlite3, re
from functools import lru_cache
from pathlib import Path
from flask import Flask, jsonify, render_template, request
import tantivy

BASE = Path(__file__).resolve().parent
DB_PATH = Path(os.environ.get('USERS_DB', str(Path.home() / 'Desktop' / 'users_merged.db'))).expanduser().resolve()
INDEX_PATH = Path(os.environ.get('USERS_SEARCH_INDEX', str(Path.home() / 'Desktop' / 'users_search_index'))).expanduser().resolve()
HOST = os.environ.get('LOCAL_SEARCH_HOST', '127.0.0.1')
PORT = int(os.environ.get('LOCAL_SEARCH_PORT', '8080'))
DEFAULT_PAGE_SIZE, MAX_PAGE_SIZE, MAX_SEARCH_HITS = 25, 100, 5000
app = Flask(__name__)
app.config['JSON_AS_ASCII'] = False
app.config['MAX_CONTENT_LENGTH'] = 1024 * 1024


def connect_readonly(path):
    if not path.is_file():
        raise FileNotFoundError(f'فایل دیتابیس پیدا نشد: {path}')
    conn = sqlite3.connect(path.as_uri() + '?mode=ro', uri=True, timeout=30)
    conn.row_factory = sqlite3.Row
    conn.execute('PRAGMA query_only=ON')
    conn.execute('PRAGMA busy_timeout=30000')
    return conn


def quote_identifier(name):
    return '"' + str(name).replace('"', '""') + '"'


def detect_main_table(conn):
    candidates = []
    for (name,) in conn.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'"):
        info = conn.execute(f'PRAGMA table_info({quote_identifier(name)})').fetchall()
        pk_cols = [c for c in info if int(c[5]) > 0]
        if len(info) == 13 and len(pk_cols) == 1 and str(pk_cols[0][2]).upper() == 'INTEGER':
            candidates.append((name, info, pk_cols[0]))
    if len(candidates) != 1:
        raise RuntimeError(f'تشخیص جدول اصلی ناموفق؛ تعداد جدول‌های سازگار: {len(candidates)}')
    table, info, pk = candidates[0]
    columns = [c[1] for c in info]
    if columns.index(pk[1]) != 0:
        raise RuntimeError('کلید اصلی در ستون اول نیست؛ ترتیب ایندکس با دیتابیس سازگار نیست.')
    return table, columns, pk[1]


try:
    if not INDEX_PATH.is_dir():
        raise FileNotFoundError(f'پوشه ایندکس پیدا نشد: {INDEX_PATH}')
    SEARCH_INDEX = tantivy.Index.open(str(INDEX_PATH))
    SEARCH_INDEX.reload()
    INDEX_SEARCHER = SEARCH_INDEX.searcher()
    INDEX_DOC_COUNT = int(INDEX_SEARCHER.num_docs)
    INDEX_FIELDS = [f'C{i}' for i in range(2, 14)]
    INDEX_LOAD_ERROR = ''
except Exception as err:
    SEARCH_INDEX, INDEX_SEARCHER, INDEX_DOC_COUNT = None, None, 0
    INDEX_FIELDS = [f'C{i}' for i in range(2, 14)]
    INDEX_LOAD_ERROR = str(err)


@lru_cache(maxsize=1)
def get_schema():
    with connect_readonly(DB_PATH) as conn:
        return detect_main_table(conn)


@app.get('/')
def home():
    table, columns, pk = get_schema()
    return render_template('index.html', db_name=DB_PATH.name, table_name=table)


@app.get('/api/health')
def health():
    try:
        table, columns, pk = get_schema()
        if SEARCH_INDEX is None:
            return jsonify(ok=True, index_ready=False, error=INDEX_LOAD_ERROR, database=DB_PATH.name, table=table, columns=columns, primary_key=pk, count=0)
        return jsonify(ok=True, index_ready=True, database=DB_PATH.name, table=table, columns=columns, primary_key=pk, count=INDEX_DOC_COUNT)
    except Exception as exc:
        return jsonify(ok=False, error=str(exc)), 500


def build_query(q, fuzzy):
    # Exact mode: ordered phrase. Fuzzy mode: edit-distance tolerant terms.
    q = q.replace('"', ' ').strip()
    if fuzzy:
        terms = [t for t in q.split() if t]
        query_string = ' AND '.join(f'{t}~1' for t in terms)
    else:
        query_string = f'"{q}"'
    return SEARCH_INDEX.parse_query(query_string, INDEX_FIELDS)


@app.get('/api/search')
def search():
    q = (request.args.get('q') or '').strip()
    fuzzy = request.args.get('fuzzy', '0') == '1'
    try:
        page = max(1, min(int(request.args.get('page', '1')), 100000))
        per_page = max(10, min(int(request.args.get('per_page', str(DEFAULT_PAGE_SIZE))), MAX_PAGE_SIZE))
    except ValueError:
        page, per_page = 1, DEFAULT_PAGE_SIZE
    if SEARCH_INDEX is None:
        return jsonify(ok=False, error=f'ایندکس باز نشد: {INDEX_LOAD_ERROR}'), 503
    try:
        table, columns, pk = get_schema()
        offset = (page - 1) * per_page
        if q:
            query = build_query(q, fuzzy)
            searcher = SEARCH_INDEX.searcher()
            result = searcher.search(query, limit=min(MAX_SEARCH_HITS, offset + per_page))
            total = int(result.count)
            hits = result.hits[offset:offset + per_page] if offset < MAX_SEARCH_HITS else []
            ids = []
            for _, address in hits:
                doc = searcher.doc(address)
                rid = doc.get_first('rid')
                if rid is not None: ids.append(int(rid))
            rows = []
            if ids:
                marks = ','.join('?' for _ in ids)
                sql = f'SELECT {", ".join(quote_identifier(c) for c in columns)} FROM {quote_identifier(table)} WHERE {quote_identifier(pk)} IN ({marks})'
                with connect_readonly(DB_PATH) as conn:
                    fetched = conn.execute(sql, ids).fetchall()
                by_id = {int(r[pk]): dict(r) for r in fetched}
                rows = [by_id[rid] for rid in ids if rid in by_id]
            pages = min((total + per_page - 1) // per_page, (MAX_SEARCH_HITS + per_page - 1) // per_page)
            capped = total > MAX_SEARCH_HITS
        else:
            total = INDEX_DOC_COUNT
            pages = (total + per_page - 1) // per_page
            capped = False
            sql = f'SELECT {", ".join(quote_identifier(c) for c in columns)} FROM {quote_identifier(table)} ORDER BY {quote_identifier(pk)} LIMIT ? OFFSET ?'
            with connect_readonly(DB_PATH) as conn:
                rows = [dict(r) for r in conn.execute(sql, (per_page, offset)).fetchall()]
        return jsonify(ok=True, query=q, fuzzy=fuzzy, total=total, page=page, per_page=per_page, pages=pages, capped=capped, max_search_hits=MAX_SEARCH_HITS if q else None, columns=columns, primary_key=pk, rows=rows)
    except Exception as exc:
        return jsonify(ok=False, error=f'جستجو ناموفق: {type(exc).__name__}: {exc}'), 400


@app.get('/api/row/<int:row_id>')
def row_detail(row_id):
    try:
        table, columns, pk = get_schema()
        sql = f'SELECT {", ".join(quote_identifier(c) for c in columns)} FROM {quote_identifier(table)} WHERE {quote_identifier(pk)}=? LIMIT 1'
        with connect_readonly(DB_PATH) as conn:
            row = conn.execute(sql, (row_id,)).fetchone()
        if row is None: return jsonify(ok=False, error='رکورد پیدا نشد.'), 404
        return jsonify(ok=True, row=dict(row), columns=columns, primary_key=pk)
    except Exception as exc:
        return jsonify(ok=False, error=str(exc)), 500


@app.errorhandler(404)
def not_found(_):
    return jsonify(ok=False, error='مسیر پیدا نشد.'), 404


if __name__ == '__main__':
    print(f'Atlas Tantivy local search · Database: {DB_PATH} · Index: {INDEX_PATH} · http://{HOST}:{PORT}')
    app.run(host=HOST, port=PORT, debug=False, threaded=True)
