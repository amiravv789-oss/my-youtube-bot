# Atlas · Tantivy Local Search (UI refresh)

Flask UI for the existing SQLite database and Tantivy index. The source database and index are opened read-only. Table and column names are discovered from SQLite metadata.


## Defaults
- SQLite: `~/Desktop/users_merged.db`
- Tantivy: `~/Desktop/users_search_index`
- URL: `http://127.0.0.1:8080`

## Run
```bash
unzip atlas_tantivy_local_search_ui_fixed.zip
cd atlas_tantivy_local_search
chmod +x run.sh
./run.sh
```

The launcher reuses `/tmp/tantivy-search-env` when available or creates a local `.venv`. It installs Flask and Tantivy as needed; it does not rebuild the search index.


## Search
- **Exact (default):** quoted ordered phrase query across indexed fields.
- **Fuzzy (optional):** edit-distance tolerant terms; checkbox is off by default.
- Dynamic schema/table/column names are taken from the database metadata.
- Pagination and row detail modal are retained.
- Maximum ranked search results processed: 5,000.


## Font/UI
Vazirmatn is used for Persian text and Inter for Latin labels and technical identifiers. Google Fonts is used when network access is available; local system fallback fonts remain in the CSS stack.


## Paths
```bash
USERS_DB=/path/to/users_merged.db USERS_SEARCH_INDEX=/path/to/users_search_index ./run.sh
```
