#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
DB_PATH="${USERS_DB:-$HOME/Desktop/users_merged.db}"
INDEX_PATH="${USERS_SEARCH_INDEX:-$HOME/Desktop/users_search_index}"
[[ -f "$DB_PATH" ]] || { echo "Database not found: $DB_PATH" >&2; exit 1; }
[[ -d "$INDEX_PATH" ]] || { echo "Tantivy index not found: $INDEX_PATH" >&2; exit 1; }
if [[ -x /tmp/tantivy-search-env/bin/python ]]; then PY=/tmp/tantivy-search-env/bin/python; PIP=/tmp/tantivy-search-env/bin/pip; else python3 -m venv .venv; PY="$PWD/.venv/bin/python"; PIP="$PWD/.venv/bin/pip"; fi
if ! "$PY" -c "import flask, tantivy" >/dev/null 2>&1; then "$PIP" install -r requirements.txt; fi
export USERS_DB="$DB_PATH" USERS_SEARCH_INDEX="$INDEX_PATH"
exec "$PY" app.py
