#!/usr/bin/env python3
"""Atlas local Tantivy search. SQLite is strictly read-only."""
import os, sqlite3, re
from functools import lru_cache
from pathlib import Path
from flask import Flask, jsonify, render_template, request
import tantivy

BASE = Path(__file__).resolve().parent
DB_PATH = Path(os.environ.get('USERS_DB', str(Path.home() / 'Desktop' / 'users_merged.db'))).expanduser().resolve()
INDEX_PATH = Path(os.environ.get('USERS_SEARCH_INDEX', str(Path.home() / 'Desktop' / 'users_search_index'))).expanduser().resolve()
HOST = os.environ.get('LOCAL_SEARCH_HOST', '127.0.0.1')
PORT = int(os.environ.get('LOCAL_SEARCH_PORT', '8080'))
DEFAULT_PAGE_SIZE, MAX_PAGE_SIZE, MAX_SEARCH_HITS = 25, 100, 5000
app = Flask(__name__)
app.config['JSON_AS_ASCII'] = False
app.config['MAX_CONTENT_LENGTH'] = 1024 * 1024

FIELD_LABELS = {
    'id':'شناسه','national_code':'کد ملی','nationalcode':'کد ملی','full_name':'نام و نام خانوادگی','fullname':'نام و نام خانوادگی',
    'name':'نام و نام خانوادگی','first_name':'نام','firstname':'نام','last_name':'نام خانوادگی','lastname':'نام خانوادگی',
    'father_name':'نام پدر','birth_date':'تاریخ تولد','birthdate':'تاریخ تولد','birth_place':'محل تولد','birthplace':'محل تولد',
    'address':'آدرس','city':'شهر','province':'استان','postal_code':'کد پستی','postalcode':'کد پستی','mobile':'شماره موبایل','phone':'تلفن ثابت','card':'اطلاعات کارت'
}
POSITION_LABELS = ['شناسه','کد ملی','نام و نام خانوادگی','نام پدر','تاریخ تولد','محل تولد','آدرس','شهر','استان','کد پستی','شماره موبایل','تلفن ثابت','اطلاعات کارت']

def get_labels(columns):
    result = {}
    for i, col in enumerate(columns):
        norm = re.sub(r'[^a-z0-9]', '', str(col).lower())
        label = FIELD_LABELS.get(str(col).lower()) or FIELD_LABELS.get(norm)
        if not label and str(col).upper().startswith('C') and str(col)[1:].isdigit():
            label = POSITION_LABELS[i] if i < len(POSITION_LABELS) else f'اطلاعات {i+1}'
        result[col] = label or (POSITION_LABELS[i] if i < len(POSITION_LABELS) else f'اطلاعات {i+1}')
    return result

def connect_readonly(path):
    if not path.is_file():
        raise FileNotFoundError(f'فایل دیتابیس پیدا نشد: {path}')
    conn = sqlite3.connect(path.as_uri() + '?mode=ro', uri=True, timeout=30)
    conn.row_factory = sqlite3.Row
    conn.execute('PRAGMA query_only=ON')
    conn.execute('PRAGMA busy_timeout=30000')
    return conn

def quote_identifier(name):
    return '"' + str(name).replace('"', '""') + '"'

def detect_main_table(conn):
    candidates=[]
    for (name,) in conn.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'"):
        info=conn.execute(f'PRAGMA table_info({quote_identifier(name)})').fetchall()
        pks=[c for c in info if int(c[5])>0]
        if len(info)==13 and len(pks)==1 and str(pks[0][2]).upper()=='INTEGER':
            candidates.append((name,info,pks[0]))
    if len(candidates)!=1:
        raise RuntimeError(f'تشخیص جدول اصلی ناموفق؛ تعداد جدول‌های سازگار: {len(candidates)}')
    table,info,pk=candidates[0]
    columns=[c[1] for c in info]
    if columns.index(pk[1])!=0:
        raise RuntimeError('کلید اصلی در ستون اول نیست؛ ترتیب ایندکس با دیتابیس سازگار نیست.')
    return table,columns,pk[1]

try:
    if not INDEX_PATH.is_dir(): raise FileNotFoundError(f'پوشه ایندکس پیدا نشد: {INDEX_PATH}')
    SEARCH_INDEX=tantivy.Index.open(str(INDEX_PATH))
    SEARCH_INDEX.reload()
    INDEX_DOC_COUNT=int(SEARCH_INDEX.searcher().num_docs)
    INDEX_FIELDS=[f'C{i}' for i in range(2,14)]
    INDEX_LOAD_ERROR=''
except Exception as err:
    SEARCH_INDEX,INDEX_DOC_COUNT=None,0
    INDEX_FIELDS=[f'C{i}' for i in range(2,14)]
    INDEX_LOAD_ERROR=str(err)

@lru_cache(maxsize=1)
def get_schema():
    with connect_readonly(DB_PATH) as conn: return detect_main_table(conn)


def _query_token(value):
    """Return one safe literal token for Tantivy's query parser."""
    return '"' + value.replace('\\', '\\\\').replace('"', '\\"') + '"'


def build_query(q, fuzzy, search_fields=None, field_filters=None):
    """Build one conjunctive query compatible with Tantivy's BASIC index.

    Every token from the main query must match somewhere in the selected
    search fields. Every active column filter is added as a field-scoped AND
    clause, so filters are applied by Tantivy before the hit limit/pagination.
    The returned candidates are still verified against SQLite substring
    matching to preserve the UI's filter semantics.
    """
    terms = re.findall(r"[\w]+", q or '', flags=re.UNICODE)
    active_fields = list(search_fields or INDEX_FIELDS)
    clauses = []

    if terms:
        if len(terms) > 16:
            raise ValueError('حداکثر ۱۶ واژه در هر جستجو مجاز است.')
        # Query parser's default fields are searched for each term. AND means
        # every term must exist, but terms may occur in different columns.
        clauses.append('(' + ' AND '.join(_query_token(t) for t in terms) + ')')

    for field_name, raw_value in (field_filters or {}).items():
        if field_name not in INDEX_FIELDS:
            continue
        filter_terms = re.findall(r"[\w]+", str(raw_value), flags=re.UNICODE)
        if not filter_terms:
            continue
        if len(filter_terms) > 16:
            raise ValueError('هر فیلتر حداکثر می‌تواند ۱۶ واژه داشته باشد.')
        # A filter is restricted to its own database column, and all its
        # tokens are required. This prevents matching the filter in another
        # field (e.g. father name text appearing in an address).
        clauses.append('(' + ' AND '.join(
            f'{field_name}:{_query_token(term)}' for term in filter_terms
        ) + ')')

    if not clauses:
        raise ValueError('عبارت جستجو یا حداقل یک فیلتر معتبر وارد کنید.')

    query_string = ' AND '.join(clauses)
    fuzzy_config = None
    if fuzzy and terms:
        # Fuzzy applies to the main search fields. SQLite verification below
        # keeps column filters strict, even when a filter column is also among
        # the general search fields.
        fuzzy_config = {field: (False, 1, True) for field in active_fields}

    return SEARCH_INDEX.parse_query(
        query_string,
        active_fields,
        fuzzy_fields=fuzzy_config,
        conjunction_by_default=True,
    )


def filter_sql_for(columns, pk, args):
    filters={c:(args.get('filter_'+c) or '').strip() for c in columns if c!=pk}
    filters={c:v for c,v in filters.items() if v}
    clauses=[f'instr(lower(coalesce({quote_identifier(c)}, "")), lower(?)) > 0' for c in filters]
    values=list(filters.values())
    return filters, clauses, values


@app.get('/')
def home():
    table,columns,pk=get_schema()
    return render_template('index.html',db_name=DB_PATH.name,table_name=table)


@app.get('/api/health')
def health():
    try:
        table,columns,pk=get_schema()
        fields=[{'name':c,'index_field':f'C{i}'} for i,c in enumerate(columns,start=1) if i>=2]
        return jsonify(ok=True,index_ready=SEARCH_INDEX is not None,error=INDEX_LOAD_ERROR if SEARCH_INDEX is None else '',database=DB_PATH.name,table=table,columns=columns,primary_key=pk,count=INDEX_DOC_COUNT,fields=fields,labels=get_labels(columns))
    except Exception as exc: return jsonify(ok=False,error=str(exc)),500


@app.get('/api/search')
def search():
    q=(request.args.get('q') or '').strip()
    fuzzy=request.args.get('fuzzy','0')=='1'
    try:
        page=max(1,min(int(request.args.get('page','1')),100000))
        per_page=max(10,min(int(request.args.get('per_page',str(DEFAULT_PAGE_SIZE))),MAX_PAGE_SIZE))
    except ValueError: page,per_page=1,DEFAULT_PAGE_SIZE
    if SEARCH_INDEX is None: return jsonify(ok=False,error=f'ایندکس باز نشد: {INDEX_LOAD_ERROR}'),503
    try:
        table,columns,pk=get_schema(); offset=(page-1)*per_page
        filters,filter_clauses,filter_values=filter_sql_for(columns,pk,request.args)
        select_cols=', '.join(quote_identifier(c) for c in columns)
        where_filter=(' WHERE '+' AND '.join(filter_clauses)) if filter_clauses else ''
        if q or filters:
            # Apply every active filter as a field-scoped Tantivy AND clause
            # before taking the hit window. Do not special-case only father
            # name: national code, full name, birth date, and every other
            # indexed column follow the same strict rule.
            field_filters = {
                f'C{columns.index(col) + 1}': value
                for col, value in filters.items()
                if col != pk and columns.index(col) > 0
            }
            query_fields = INDEX_FIELDS
            labels_by_col = get_labels(columns)
            father_filter_active = any(
                value and ('پدر' in labels_by_col.get(col, ''))
                for col, value in filters.items()
            )
            if q and father_filter_active:
                # With a father-name filter, the free-text term is interpreted
                # as a person's-name search (not address/notes/etc.).
                name_columns = [
                    col for col in columns
                    if col != pk and (
                        'نام و نام خانوادگی' in labels_by_col.get(col, '')
                        or 'نام کامل' in labels_by_col.get(col, '')
                    )
                ]
                if name_columns:
                    query_fields = [f'C{columns.index(name_columns[0]) + 1}']

            searcher=SEARCH_INDEX.searcher()
            result=searcher.search(
                build_query(q, fuzzy, query_fields, field_filters),
                limit=MAX_SEARCH_HITS
            )
            total_index=int(result.count)
            hits=result.hits[:MAX_SEARCH_HITS]
            ids=[]
            for _,addr in hits:
                doc=searcher.doc(addr)
                rid=doc.get_first('rid')
                if rid is not None: ids.append(int(rid))
            rows_by_id={}
            if ids:
                # Batch safely below SQLite's parameter limit.
                with connect_readonly(DB_PATH) as conn:
                    for start in range(0,len(ids),800):
                        batch=ids[start:start+800]
                        marks=','.join('?' for _ in batch)
                        sql=f'SELECT {select_cols} FROM {quote_identifier(table)} WHERE {quote_identifier(pk)} IN ({marks})'
                        fetched=conn.execute(sql,batch).fetchall()
                        rows_by_id.update({int(r[pk]):dict(r) for r in fetched})
            ordered=[rows_by_id[rid] for rid in ids if rid in rows_by_id]
            if filters:
                def passes(row):
                    return all(value.casefold() in str(row.get(col) or '').casefold() for col,value in filters.items())
                ordered=[r for r in ordered if passes(r)]
                total=len(ordered)
                rows=ordered[offset:offset+per_page]
                capped=total_index>MAX_SEARCH_HITS
            else:
                total=total_index
                rows=ordered[offset:offset+per_page]
                capped=total_index>MAX_SEARCH_HITS
            pages=min((total+per_page-1)//per_page,(MAX_SEARCH_HITS+per_page-1)//per_page)
        else:
            where_sql=where_filter
            with connect_readonly(DB_PATH) as conn:
                total=conn.execute(f'SELECT COUNT(*) FROM {quote_identifier(table)}{where_sql}',filter_values).fetchone()[0]
                fetched=conn.execute(f'SELECT {select_cols} FROM {quote_identifier(table)}{where_sql} ORDER BY {quote_identifier(pk)} LIMIT ? OFFSET ?',filter_values+[per_page,offset]).fetchall()
            rows=[dict(r) for r in fetched]
            pages=(total+per_page-1)//per_page
            capped=False
        return jsonify(ok=True,query=q,fuzzy=fuzzy,total=total,page=page,per_page=per_page,pages=pages,capped=capped,max_search_hits=MAX_SEARCH_HITS if q else None,columns=columns,primary_key=pk,rows=rows,filters=filters,labels=get_labels(columns))
    except Exception as exc:
        return jsonify(ok=False,error=f'جستجو ناموفق: {type(exc).__name__}: {exc}'),400

@app.get('/api/row/<int:row_id>')
def row_detail(row_id):
    try:
        table,columns,pk=get_schema(); select_cols=', '.join(quote_identifier(c) for c in columns)
        with connect_readonly(DB_PATH) as conn: row=conn.execute(f'SELECT {select_cols} FROM {quote_identifier(table)} WHERE {quote_identifier(pk)}=? LIMIT 1',(row_id,)).fetchone()
        if row is None: return jsonify(ok=False,error='رکورد پیدا نشد.'),404
        return jsonify(ok=True,row=dict(row),columns=columns,primary_key=pk,labels=get_labels(columns))
    except Exception as exc: return jsonify(ok=False,error=str(exc)),500

@app.errorhandler(404)
def not_found(_): return jsonify(ok=False,error='مسیر پیدا نشد.'),404


if __name__=='__main__':
    print(f'Atlas Tantivy local search · Database: {DB_PATH} · Index: {INDEX_PATH} · http://{HOST}:{PORT}')
    app.run(host=HOST,port=PORT,debug=False,threaded=True)
