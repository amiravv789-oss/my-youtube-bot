#!/usr/bin/env python3
"""Atlas local search. Original customer database is opened read-only.
A separate FTS5 sidecar index is built by build_search_index.py.
"""
import os
import sqlite3
from pathlib import Path
from flask import Flask, render_template, request, jsonify

BASE = Path(__file__).resolve().parent
DB_PATH = Path(os.environ.get("CUSTOMERS_DB", BASE / "users_merged.db")).resolve()
INDEX_PATH = Path(os.environ.get("CUSTOMERS_INDEX", str(DB_PATH) + ".search-index.db")).resolve()
HOST = os.environ.get("ATLAS_HOST", "127.0.0.1")
PORT = int(os.environ.get("ATLAS_PORT", "8080"))
PER_PAGE_DEFAULT, PER_PAGE_MAX = 25, 100
MIN_SEARCH_CHARS = 3

FIELDS = {
    "national_code": "کد ملی", "full_name": "نام و نام خانوادگی",
    "father_name": "نام پدر", "birth_date": "تاریخ تولد",
    "birth_place": "محل تولد", "address": "آدرس", "city": "شهر",
    "province": "استان", "postal_code": "کد پستی", "mobile": "موبایل",
    "phone": "تلفن ثابت", "card": "شماره کارت / مقدار ذخیره‌شده",
}
TABLE_COLUMNS = tuple(FIELDS)
app = Flask(__name__)
app.config["JSON_AS_ASCII"] = False
app.config["MAX_CONTENT_LENGTH"] = 1024 * 1024


def connect_readonly(path):
    if not path.is_file():
        raise FileNotFoundError(f"فایل پیدا نشد: {path}")
    conn = sqlite3.connect(path.as_uri() + "?mode=ro", uri=True, timeout=30)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA query_only=ON")
    conn.execute("PRAGMA busy_timeout=30000")
    return conn


def get_conn():
    return connect_readonly(DB_PATH)


def get_index_conn():
    return connect_readonly(INDEX_PATH)


def table_columns(conn):
    return {r["name"] for r in conn.execute("PRAGMA table_info(users)")}


def ensure_schema(conn):
    missing = {"id", *TABLE_COLUMNS} - table_columns(conn)
    if missing:
        raise RuntimeError("ستون‌های موردنیاز در جدول users پیدا نشدند: " + ", ".join(sorted(missing)))


def index_ready():
    if not INDEX_PATH.is_file():
        return False, "ایندکس جستجو ساخته نشده است. ابتدا build_search_index.py را اجرا کنید."
    try:
        with get_index_conn() as ix, get_conn() as db:
            ensure_schema(db)
            meta = dict(ix.execute("SELECT key, value FROM index_meta"))
            st = DB_PATH.stat()
            wal = Path(str(DB_PATH) + "-wal")
            wal_stat = wal.stat() if wal.exists() else None
            valid = (meta.get("source_size") == str(st.st_size)
                     and meta.get("source_mtime_ns") == str(st.st_mtime_ns)
                     and meta.get("source_wal_size") == str(wal_stat.st_size if wal_stat else 0)
                     and meta.get("source_wal_mtime_ns") == str(wal_stat.st_mtime_ns if wal_stat else 0)
                     and meta.get("source_path") == str(DB_PATH))
            return valid, "" if valid else "دیتابیس اصلی بعد از ساخت ایندکس تغییر کرده؛ ایندکس را دوباره بسازید."
    except Exception as exc:
        return False, f"ایندکس قابل استفاده نیست: {exc}. آن را دوباره بسازید."


def parse_pagination():
    try:
        page = int(request.args.get("page", "1"))
        per_page = int(request.args.get("per_page", str(PER_PAGE_DEFAULT)))
    except ValueError:
        page, per_page = 1, PER_PAGE_DEFAULT
    return max(1, min(page, 1_000_000)), max(10, min(per_page, PER_PAGE_MAX))


def fts_phrase(value):
    # FTS5 quoted phrase; double quotes inside a phrase are escaped by doubling.
    return '"' + value.replace('"', '""') + '"'


def like_contains(value):
    return "%" + value.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_") + "%"


@app.get("/")
def index():
    return render_template("index.html", db_name=DB_PATH.name)


@app.get("/api/health")
def health():
    try:
        with get_conn() as conn:
            ensure_schema(conn)
        ready, message = index_ready()
        count = None
        if ready:
            with get_index_conn() as ix:
                meta = dict(ix.execute("SELECT key, value FROM index_meta"))
                count = int(meta.get("row_count", "0"))
        return jsonify(ok=True, database=DB_PATH.name, count=count,
                       index_ready=ready, index_message=message,
                       min_search_chars=MIN_SEARCH_CHARS,
                       columns=["id", *TABLE_COLUMNS], labels={"id": "شناسه", **FIELDS})
    except Exception as exc:
        return jsonify(ok=False, error=str(exc)), 500


@app.get("/api/search")
def search():
    q = (request.args.get("q") or "").strip()
    page, per_page = parse_pagination()
    active_filters = {c: (request.args.get(c) or "").strip() for c in TABLE_COLUMNS}
    active_filters = {k: v for k, v in active_filters.items() if v}
    terms = ([q] if q else []) + list(active_filters.values())
    short = [v for v in terms if len(v) < MIN_SEARCH_CHARS and not (v == "09" and (v == q or active_filters.get("mobile") == v))]
    if short:
        return jsonify(ok=False, error=f"برای جستجوی سریع حداقل {MIN_SEARCH_CHARS} نویسه وارد کنید."), 400

    try:
        ready, message = index_ready()
        if not ready:
            return jsonify(ok=False, error=message), 503
        where, params = [], []
        if q:
            if q == "09":
                where.append("rowid IN (SELECT rowid FROM mobile_prefix WHERE value GLOB '09*')")
            else:
                where.append("search_fts MATCH ?")
                params.append(fts_phrase(q))
        for col, value in active_filters.items():
            if col == "mobile" and value == "09":
                where.append("rowid IN (SELECT rowid FROM mobile_prefix WHERE value GLOB '09*')")
            else:
                where.append('"' + col + '" LIKE ?')
                params.append(like_contains(value))
        where_sql = (" WHERE " + " AND ".join(where)) if where else ""
        offset = (page - 1) * per_page
        with get_index_conn() as ix:
            if where:
                total = ix.execute("SELECT COUNT(*) FROM search_fts" + where_sql, params).fetchone()[0]
                ids = [r[0] for r in ix.execute(
                    "SELECT rowid FROM search_fts" + where_sql + " ORDER BY rowid LIMIT ? OFFSET ?",
                    params + [per_page, offset]).fetchall()]
            else:
                meta = dict(ix.execute("SELECT key, value FROM index_meta"))
                total = int(meta.get("row_count", "0"))
                with get_conn() as db:
                    ids = [r[0] for r in db.execute("SELECT id FROM users ORDER BY id LIMIT ? OFFSET ?", (per_page, offset))]
        rows = []
        if ids:
            placeholders = ",".join("?" for _ in ids)
            with get_conn() as db:
                ensure_schema(db)
                found = {r["id"]: dict(r) for r in db.execute(
                    f'SELECT "id", ' + ", ".join(f'"{c}"' for c in TABLE_COLUMNS)
                    + f' FROM users WHERE id IN ({placeholders})', ids).fetchall()}
            rows = [found[i] for i in ids if i in found]
        return jsonify(ok=True, total=total, page=page, per_page=per_page,
                       pages=(total + per_page - 1) // per_page, rows=rows,
                       filters=active_filters, labels={"id": "شناسه", **FIELDS})
    except sqlite3.OperationalError as exc:
        return jsonify(ok=False, error=f"خطای جستجو: {exc}"), 400
    except Exception as exc:
        return jsonify(ok=False, error=str(exc)), 500


@app.get("/api/row/<int:row_id>")
def row_detail(row_id):
    try:
        with get_conn() as conn:
            ensure_schema(conn)
            cols = ", ".join(['"id"'] + [f'"{c}"' for c in TABLE_COLUMNS])
            row = conn.execute(f"SELECT {cols} FROM users WHERE id=?", (row_id,)).fetchone()
            if row is None:
                return jsonify(ok=False, error="رکورد پیدا نشد"), 404
            return jsonify(ok=True, row=dict(row), labels={"id": "شناسه", **FIELDS})
    except Exception as exc:
        return jsonify(ok=False, error=str(exc)), 500


@app.errorhandler(404)
def not_found(_):
    return jsonify(ok=False, error="مسیر پیدا نشد"), 404


if __name__ == "__main__":
    print(f"Database (read-only): {DB_PATH}")
    print(f"Search index: {INDEX_PATH}")
    print(f"Local Search: http://{HOST}:{PORT}")
    if not DB_PATH.is_file():
        print("هشدار: فایل users_merged.db را کنار app.py قرار دهید.")
    app.run(host=HOST, port=PORT, debug=False, threaded=True)
