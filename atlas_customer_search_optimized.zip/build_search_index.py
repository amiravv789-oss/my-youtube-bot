#!/usr/bin/env python3
"""Build a separate FTS5 trigram index. Never writes to the source database."""
import os
import sqlite3
import sys
from pathlib import Path

BASE = Path(__file__).resolve().parent
SOURCE = Path(os.environ.get("CUSTOMERS_DB", BASE / "users_merged.db")).resolve()
TARGET = Path(os.environ.get("CUSTOMERS_INDEX", str(SOURCE) + ".search-index.db")).resolve()
COLS = ("national_code", "full_name", "father_name", "birth_date", "birth_place",
        "address", "city", "province", "postal_code", "mobile", "phone", "card")
BATCH = 5000


def main():
    if not SOURCE.is_file():
        raise SystemExit(f"فایل دیتابیس پیدا نشد: {SOURCE}\nآن را کنار این اسکریپت با نام users_merged.db قرار دهید.")
    src = sqlite3.connect(SOURCE.as_uri() + "?mode=ro", uri=True, timeout=60)
    src.row_factory = sqlite3.Row
    src.execute("PRAGMA query_only=ON")
    cols = {r["name"] for r in src.execute("PRAGMA table_info(users)")}
    missing = {"id", *COLS} - cols
    if missing:
        raise SystemExit("ستون‌های موردنیاز پیدا نشدند: " + ", ".join(sorted(missing)))
    try:
        probe = sqlite3.connect(":memory:")
        probe.execute("CREATE VIRTUAL TABLE t USING fts5(x, tokenize='trigram')")
        probe.close()
    except sqlite3.Error as exc:
        raise SystemExit(f"نسخه SQLite این Python از FTS5 trigram پشتیبانی نمی‌کند: {exc}")

    tmp = TARGET.with_suffix(TARGET.suffix + ".building")
    if tmp.exists():
        tmp.unlink()
    if TARGET.exists():
        try:
            old = sqlite3.connect(TARGET)
            old_meta = dict(old.execute("SELECT key, value FROM index_meta"))
            old.close()
            st_now = SOURCE.stat()
            wal = Path(str(SOURCE) + "-wal")
            wal_stat = wal.stat() if wal.exists() else None
            if (old_meta.get("source_path") == str(SOURCE)
                and old_meta.get("source_size") == str(st_now.st_size)
                and old_meta.get("source_mtime_ns") == str(st_now.st_mtime_ns)
                and old_meta.get("source_wal_size") == str(wal_stat.st_size if wal_stat else 0)
                and old_meta.get("source_wal_mtime_ns") == str(wal_stat.st_mtime_ns if wal_stat else 0)
                and old_meta.get("format_version") == "1"):
                print(f"ایندکس از قبل به‌روز است: {TARGET}")
                src.close()
                return
        except sqlite3.Error:
            pass
        print(f"ایندکس قبلی دست‌نخورده می‌ماند تا ساخت نسخه جدید کامل شود: {TARGET}")
    dst = sqlite3.connect(tmp)
    dst.execute("PRAGMA journal_mode=WAL")
    dst.execute("PRAGMA synchronous=NORMAL")
    dst.execute("PRAGMA temp_store=MEMORY")
    col_sql = ", ".join('"' + c + '"' for c in COLS)
    dst.execute("CREATE VIRTUAL TABLE search_fts USING fts5(" + col_sql + ", tokenize='trigram')")
    dst.execute("CREATE TABLE mobile_prefix(value TEXT NOT NULL, rowid INTEGER NOT NULL)")
    dst.execute("CREATE INDEX idx_mobile_prefix_value ON mobile_prefix(value)")
    dst.execute("CREATE TABLE index_meta(key TEXT PRIMARY KEY, value TEXT NOT NULL)")
    total = src.execute("SELECT COUNT(*) FROM users").fetchone()[0]
    last = None
    copied = 0
    try:
        while True:
            if last is None:
                batch = src.execute(
                    f'SELECT "id", {col_sql} FROM users ORDER BY id LIMIT ?', (BATCH,)).fetchall()
            else:
                batch = src.execute(
                    f'SELECT "id", {col_sql} FROM users WHERE id > ? ORDER BY id LIMIT ?',
                    (last, BATCH)).fetchall()
            if not batch:
                break
            payload = [tuple(row[c] for c in ("id", *COLS)) for row in batch]
            marks = ",".join("?" for _ in range(len(COLS) + 1))
            dst.executemany(f"INSERT INTO search_fts(rowid, {col_sql}) VALUES ({marks})", payload)
            dst.executemany("INSERT INTO mobile_prefix(value, rowid) VALUES (?, ?)",
                            [(str(row["mobile"] or ""), int(row["id"])) for row in batch])
            last = batch[-1]["id"]
            copied += len(batch)
            if copied % 50000 < BATCH or copied == total:
                print(f"ایندکس‌سازی: {copied:,} / {total:,}", flush=True)
        st = SOURCE.stat()
        wal = Path(str(SOURCE) + "-wal")
        wal_stat = wal.stat() if wal.exists() else None
        meta = {
            "source_path": str(SOURCE), "source_size": str(st.st_size),
            "source_mtime_ns": str(st.st_mtime_ns),
            "source_wal_size": str(wal_stat.st_size if wal_stat else 0),
            "source_wal_mtime_ns": str(wal_stat.st_mtime_ns if wal_stat else 0),
            "row_count": str(copied),
            "format_version": "1",
        }
        dst.executemany("INSERT INTO index_meta(key,value) VALUES (?,?)", meta.items())
        # Refuse to publish an index if the source changed while it was being read.
        st_after = SOURCE.stat()
        wal_after = Path(str(SOURCE) + "-wal")
        wal_after_stat = wal_after.stat() if wal_after.exists() else None
        if (st_after.st_size != st.st_size or st_after.st_mtime_ns != st.st_mtime_ns
            or (wal_after_stat.st_size if wal_after_stat else 0) != (wal_stat.st_size if wal_stat else 0)
            or (wal_after_stat.st_mtime_ns if wal_after_stat else 0) != (wal_stat.st_mtime_ns if wal_stat else 0)):
            raise RuntimeError("دیتابیس هنگام ساخت ایندکس تغییر کرد؛ دوباره اجرا کنید.")
        dst.commit()
        dst.execute("PRAGMA wal_checkpoint(TRUNCATE)")
        dst.close()
        # Atomic replacement after a complete build.
        os.replace(tmp, TARGET)
        try:
            os.chmod(TARGET, 0o600)
        except OSError:
            pass
        print(f"تمام شد. ایندکس جداگانه ساخته شد: {TARGET}")
        print("فایل دیتابیس اصلی هیچ تغییری نکرده است.")
    except Exception:
        dst.close()
        raise
    finally:
        src.close()


if __name__ == "__main__":
    main()
