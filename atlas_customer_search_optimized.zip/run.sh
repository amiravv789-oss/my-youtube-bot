#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python3 -m venv .venv 2>/dev/null || true
. .venv/bin/activate
pip install -r requirements.txt
# This creates/refreshes a separate index; users_merged.db is never modified.
python build_search_index.py
python app.py
