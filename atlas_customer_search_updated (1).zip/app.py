#!/usr/bin/env python3
import os
import sqlite3
from pathlib import Path
from flask import Flask, render_template, request, jsonify

BASE = Path(__file__).resolve().parent
DB_PATH = Path(os.environ.get("CUSTOMERS_DB", BASE / "users_merged.db")).resolve()
HOST = "127.0.0.1"
PORT = 8080
PER_PAGE_DEFAULT = 25
PER_PAGE_MAX = 100

FIELDS = {
    "national_code": "کد ملی",
    "full_name": "نام و نام خانوادگی",
    "father_name": "نام پدر",
    "birth_date": "تاریخ تولد",
    "birth_place": "محل تولد",
    "address": "آدرس",
    "city": "شهر",
    "province": "استان",
    "postal_code": "کد پستی",
    "mobile": "موبایل",
    "phone": "تلفن ثابت",
    "card": "شماره کارت / مقدار ذخیره‌شده",
}
TABLE_COLUMNS = tuple(FIELDS.keys())

app = Flask(__name__)
app.config["JSON_AS_ASCII"] = False
app.config["MAX_CONTENT_LENGTH"] = 1024 * 1024

def get_conn():
    if not DB_PATH.is_file():
        raise FileNotFoundError(f"Database not found: {DB_PATH}")
    conn = sqlite3.connect(DB_PATH.as_uri() + "?mode=ro", uri=True, timeout=15)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA query_only=ON")
    conn.execute("PRAGMA busy_timeout=15000")
    return conn

def table_columns(conn):
    return {r["name"] for r in conn.execute("PRAGMA table_info(users)").fetchall()}

def ensure_schema(conn):
    cols = table_columns(conn)
    required = {"id", *TABLE_COLUMNS}
    missing = required - cols
    if missing:
        raise RuntimeError(
            "ساختار دیتابیس با نسخه جدید سازگار نیست. ستون‌های مفقود: "
            + ", ".join(sorted(missing))
        )
    return cols

def parse_pagination():
    try:
        page = int(request.args.get("page", "1"))
        per_page = int(request.args.get("per_page", str(PER_PAGE_DEFAULT)))
    except ValueError:
        page, per_page = 1, PER_PAGE_DEFAULT
    return max(1, min(page, 1000000)), max(10, min(per_page, PER_PAGE_MAX))

@app.get("/")
def index():
    return render_template("index.html", db_name=DB_PATH.name)

@app.get("/api/health")
def health():
    try:
        with get_conn() as conn:
            cols = ensure_schema(conn)
            count = conn.execute("SELECT COUNT(*) FROM users").fetchone()[0]
        return jsonify(ok=True, database=DB_PATH.name, count=count,
                       columns=["id", *TABLE_COLUMNS],
                       labels={"id": "شناسه", **FIELDS})
    except Exception as e:
        return jsonify(ok=False, error=str(e)), 500

@app.get("/api/search")
def search():
    q = (request.args.get("q") or "").strip()
    page, per_page = parse_pagination()
    try:
        with get_conn() as conn:
            ensure_schema(conn)
            where, params = [], []
            if q:
                where.append("(" + " OR ".join(f'"{c}" LIKE ?' for c in TABLE_COLUMNS) + ")")
                params.extend([f"%{q}%"] * len(TABLE_COLUMNS))

            active_filters = {}
            for col in TABLE_COLUMNS:
                value = (request.args.get(col) or "").strip()
                if value:
                    where.append(f'"{col}" LIKE ?')
                    params.append(f"%{value}%")
                    active_filters[col] = value

            where_sql = (" WHERE " + " AND ".join(where)) if where else ""
            total = conn.execute(
                f"SELECT COUNT(*) FROM users{where_sql}", params
            ).fetchone()[0]
            offset = (page - 1) * per_page
            select_cols = ", ".join(['"id"'] + [f'"{c}"' for c in TABLE_COLUMNS])
            rows = conn.execute(
                f"SELECT {select_cols} FROM users{where_sql} ORDER BY id LIMIT ? OFFSET ?",
                params + [per_page, offset]
            ).fetchall()
            return jsonify(
                ok=True, total=total, page=page, per_page=per_page,
                pages=(total + per_page - 1) // per_page,
                rows=[dict(r) for r in rows],
                filters=active_filters,
                labels={"id": "شناسه", **FIELDS}
            )
    except Exception as e:
        return jsonify(ok=False, error=str(e)), 500

@app.get("/api/row/<int:row_id>")
def row_detail(row_id):
    try:
        with get_conn() as conn:
            ensure_schema(conn)
            select_cols = ", ".join(['"id"'] + [f'"{c}"' for c in TABLE_COLUMNS])
            row = conn.execute(
                f"SELECT {select_cols} FROM users WHERE id=?", (row_id,)
            ).fetchone()
            if row is None:
                return jsonify(ok=False, error="رکورد پیدا نشد"), 404
            return jsonify(ok=True, row=dict(row), labels={"id": "شناسه", **FIELDS})
    except Exception as e:
        return jsonify(ok=False, error=str(e)), 500

@app.errorhandler(404)
def not_found(_):
    return jsonify(ok=False, error="مسیر پیدا نشد"), 404

if __name__ == "__main__":
    print(f"Database: {DB_PATH}")
    print(f"Local Search: http://{HOST}:{PORT}")
    if not DB_PATH.is_file():
        print("هشدار: فایل users_merged.db را کنار app.py قرار دهید.")
    app.run(host=HOST, port=PORT, debug=False, threaded=True)
