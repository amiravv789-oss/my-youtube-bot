const $ = id => document.getElementById(id);
const fields = [
  ["national_code","کد ملی","▣"],["full_name","نام و نام خانوادگی","♙"],
  ["father_name","نام پدر","♧"],["birth_date","تاریخ تولد","▦"],
  ["birth_place","محل تولد","⌖"],["address","آدرس","⌂"],
  ["city","شهر","⌖"],["province","استان","◈"],
  ["postal_code","کد پستی","▤"],["mobile","موبایل","☎"],
  ["phone","تلفن ثابت","☏"],["card","شماره کارت / مقدار ذخیره‌شده","▣"]
];
let page=1,pages=0,debounce=null,total=0,initialized=false;
const esc=v=>String(v??"—").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const fa=n=>Number(n||0).toLocaleString("fa-IR");
function toast(s){$("toast").textContent=s;$("toast").classList.add("show");setTimeout(()=>$("toast").classList.remove("show"),2600)}
function buildFilters(){
  $("filterGrid").innerHTML=fields.map(([key,label,ico])=>`<label class="filter-field"><span>${ico} ${label}</span><input id="filter_${key}" data-filter="${key}" placeholder="فیلتر ${label}" autocomplete="off"></label>`).join("");
  document.querySelectorAll("[data-filter]").forEach(el=>el.addEventListener("input",scheduleSearch));
}
function params(){
  const p=new URLSearchParams({q:$("query").value.trim(),page,per_page:$("perPage").value});
  fields.forEach(([key])=>{const v=$("filter_"+key)?.value.trim();if(v)p.set(key,v)});
  return p;
}
function activeFilters(){
  return fields.filter(([k])=>$("filter_"+k)?.value.trim()).map(([k,l])=>`${l}: ${$("filter_"+k).value.trim()}`);
}
function updateActive(){
  const a=activeFilters();
  $("activeLine").innerHTML=a.length?`<span>فیلترهای فعال:</span> ${a.map(x=>`<b>${esc(x)}</b>`).join("")}`:"";
}
async function load(){
  const body=$("results");
  body.innerHTML='<tr><td colspan="8" class="empty">در حال جستجو…</td></tr>';
  try{
    const r=await fetch("/api/search?"+params());const d=await r.json();if(!d.ok)throw Error(d.error);
    total=d.total;pages=d.pages;
    $("resultCount").textContent=fa(total);
    $("resultCaption").textContent=`${fa(total)} نتیجه پیدا شد${$("query").value.trim()?" برای عبارت جستجوی فعلی":""}`;
    $("pageInfo").textContent=`صفحه ${fa(page)} از ${fa(Math.max(1,pages))}`;
    $("prevBtn").disabled=page<=1;$("nextBtn").disabled=page>=pages;
    updateActive();
    if(!d.rows.length){
      body.innerHTML='<tr><td colspan="8" class="empty">نتیجه‌ای پیدا نشد. فیلترها را تغییر دهید.</td></tr>';
      $("mobileResults").innerHTML='<div class="empty">نتیجه‌ای پیدا نشد.</div>';return;
    }
    body.innerHTML=d.rows.map(x=>`<tr>
      <td class="id-cell">#${esc(x.id)}</td><td class="name-cell">${esc(x.full_name)}</td>
      <td>${esc(x.national_code)}</td><td>${esc(x.mobile)}</td><td>${esc(x.birth_date)}</td>
      <td>${esc(x.city)}</td><td class="masked">${esc(x.card)}</td>
      <td><button class="detail-btn" data-id="${x.id}">مشاهده ↗</button></td></tr>`).join("");
    $("mobileResults").innerHTML=d.rows.map(x=>`<article class="mobile-card">
      <div class="mobile-card-head"><strong>${esc(x.full_name)}</strong><small>#${esc(x.id)}</small></div>
      <div class="mobile-card-grid"><span>کد ملی<b>${esc(x.national_code)}</b></span><span>موبایل<b>${esc(x.mobile)}</b></span>
      <span>تاریخ تولد<b>${esc(x.birth_date)}</b></span><span>شهر<b>${esc(x.city)}</b></span><span>کارت<b>${esc(x.card)}</b></span></div>
      <button class="detail-btn" data-id="${x.id}" style="margin-top:12px">نمایش همه جزئیات</button></article>`).join("");
  }catch(e){body.innerHTML=`<tr><td colspan="8" class="empty">${esc(e.message)}</td></tr>`;toast("خطا در دریافت اطلاعات")}
}
async function health(){
  try{
    const r=await fetch("/api/health");const d=await r.json();if(!d.ok)throw Error(d.error);
    $("totalCount").textContent=fa(d.count);$("dbStatus").textContent="متصل";$("dbStatus").style.color="var(--green)";
    initialized=true;buildFilters();load();
  }catch(e){$("dbStatus").textContent="خطای اتصال";$("dbStatus").style.color="#ff7b88";$("results").innerHTML=`<tr><td colspan="8" class="empty">${esc(e.message)}</td></tr>`;toast(e.message)}
}
function doSearch(){page=1;load()}
function scheduleSearch(){clearTimeout(debounce);debounce=setTimeout(doSearch,450)}
$("searchBtn").onclick=doSearch;
$("query").addEventListener("keydown",e=>{if(e.key==="Enter")doSearch()});
$("query").addEventListener("input",scheduleSearch);
$("perPage").onchange=doSearch;
$("prevBtn").onclick=()=>{if(page>1){page--;load()}};
$("nextBtn").onclick=()=>{if(page<pages){page++;load()}};
$("resetBtn").onclick=()=>{ $("query").value="";fields.forEach(([k])=>{const el=$("filter_"+k);if(el)el.value=""});doSearch()};
document.querySelectorAll("[data-focus]").forEach(b=>b.onclick=()=>{const el=$("filter_"+b.dataset.focus);if(el)el.focus()});
document.addEventListener("click",async e=>{
  const b=e.target.closest("[data-id]");if(!b)return;
  try{
    const d=await(await fetch("/api/row/"+b.dataset.id)).json();if(!d.ok)throw Error(d.error);
    $("detailBody").innerHTML='<div class="detail-grid">'+Object.entries(d.row).map(([k,v])=>{
      const label=d.labels[k]||k;return `<div class="detail-item"><small>${esc(label)}</small><b>${esc(v||"—")}</b></div>`;
    }).join("")+'</div>';
    $("modal").classList.add("open");
  }catch(err){toast(err.message)}
});
$("modalClose").onclick=()=>$("modal").classList.remove("open");
$("modal").onclick=e=>{if(e.target===$("modal"))$("modal").classList.remove("open")};
$("themeBtn").onclick=()=>document.body.classList.toggle("light");
document.addEventListener("keydown",e=>{
  if(e.key==="/"&&!["INPUT","TEXTAREA"].includes(document.activeElement.tagName)){e.preventDefault();$("query").focus()}
  if(e.key==="Escape")$("modal").classList.remove("open")
});
health();
