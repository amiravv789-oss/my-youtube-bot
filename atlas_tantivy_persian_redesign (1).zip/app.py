#!/usr/bin/env python3
"""Local SQLite/Tantivy search. Source SQLite is opened strictly read-only."""
import os
import sqlite3
import re
from difflib import SequenceMatcher
from functools import lru_cache
from pathlib import Path
from flask import Flask, jsonify, render_template, request
import tantivy

BASE = Path(__file__).resolve().parent
DB_PATH = Path(os.environ.get("USERS_DB", str(Path.home() / "Desktop" / "users_merged.db"))).expanduser().resolve()
INDEX_PATH = Path(os.environ.get("USERS_SEARCH_INDEX", str(Path.home() / "Desktop" / "users_search_index"))).expanduser().resolve()
HOST = os.environ.get("LOCAL_SEARCH_HOST", "127.0.0.1")
PORT = int(os.environ.get("LOCAL_SEARCH_PORT", "8080"))
DEFAULT_PAGE_SIZE = 25
MAX_PAGE_SIZE = 100
MAX_SEARCH_HITS = 5000
MAX_FUZZY_SCAN = 200000

app = Flask(__name__)
app.config["JSON_AS_ASCII"] = False
app.config["MAX_CONTENT_LENGTH"] = 1024 * 1024



def connect_readonly(path: Path):
    if not path.is_file():
        raise FileNotFoundError(f"فایل دیتابیس پیدا نشد: {path}")
    conn = sqlite3.connect(path.as_uri() + "?mode=ro", uri=True, timeout=30)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA query_only=ON")
    conn.execute("PRAGMA busy_timeout=30000")
    return conn



def quote_identifier(name: str) -> str:
    return '"' + str(name).replace('"', '""') + '"'


FIELD_LABELS = {
    "id": "شناسه", "national_code": "کد ملی", "nationalcode": "کد ملی", "full_name": "نام و نام خانوادگی", "fullname": "نام و نام خانوادگی",
    "name": "نام و نام خانوادگی", "first_name": "نام", "firstname": "نام",
    "last_name": "نام خانوادگی", "lastname": "نام خانوادگی", "father_name": "نام پدر",
    "birth_date": "تاریخ تولد", "birthdate": "تاریخ تولد", "birth_place": "محل تولد", "birthplace": "محل تولد", "address": "آدرس",
    "city": "شهر", "province": "استان", "postal_code": "کد پستی", "postalcode": "کد پستی",
    "mobile": "شماره موبایل", "phone": "تلفن ثابت", "card": "اطلاعات کارت",
}
POSITION_LABELS = ["شناسه", "کد ملی", "نام و نام خانوادگی", "نام پدر", "تاریخ تولد",
                  "محل تولد", "آدرس", "شهر", "استان", "کد پستی", "شماره موبایل", "تلفن ثابت", "اطلاعات کارت"]

def get_labels(columns):
    labels = {}
    for i, col in enumerate(columns):
        normalized = re.sub(r"[^a-z0-9]", "", str(col).lower())
        label = FIELD_LABELS.get(str(col).lower()) or FIELD_LABELS.get(normalized)
        if not label and (str(col).upper().startswith("C") and str(col)[1:].isdigit()):
            label = POSITION_LABELS[i] if i < len(POSITION_LABELS) else f"اطلاعات {i + 1}"
        if not label:
            label = POSITION_LABELS[i] if i < len(POSITION_LABELS) else f"اطلاعات {i + 1}"
        labels[col] = label
    return labels

def fuzzy_score(query, row_values):
    tokens = [t for t in re.split(r"\s+", query.strip()) if t]
    if not tokens:
        return 1.0
    text = " ".join(str(v or "") for v in row_values).casefold()
    words = list(set(re.findall(r"[\w\u0600-\u06ff]+", text)))
    if query.casefold() in text:
        return 1.0
    scores = []
    for token in tokens:
        token = token.casefold()
        if token in text:
            scores.append(1.0)
            continue
        max_len_delta = max(2, len(token) // 3)
        candidates = [word for word in words if abs(len(word) - len(token)) <= max_len_delta]
        best = max((SequenceMatcher(None, token, word).ratio() for word in candidates), default=0.0)
        if best < 0.66:
            return 0.0
        scores.append(best)
    return sum(scores) / len(scores)



def detect_main_table(conn):
    candidates = []
    for (name,) in conn.execute(
        "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'"
    ):
        info = conn.execute(f"PRAGMA table_info({quote_identifier(name)})").fetchall()
        if len(info) != 13:
            continue
        pk_cols = [c for c in info if int(c[5]) > 0]
        if len(pk_cols) == 1 and str(pk_cols[0][2]).upper() == "INTEGER":
            candidates.append((name, info, pk_cols[0]))
    if len(candidates) != 1:
        raise RuntimeError(f"تشخیص جدول اصلی ناموفق بود؛ تعداد جدول‌های سازگار: {len(candidates)}")
    table, info, pk = candidates[0]
    columns = [c[1] for c in info]
    pk_name = pk[1]
    if columns.index(pk_name) != 0:
        # The search-index build stored the source row's first column as rid.
        # A primary key outside column 1 would not match that index mapping.
        raise RuntimeError("کلید اصلی در ستون اول جدول نیست؛ ترتیب ایندکس با دیتابیس سازگار نیست.")
    return table, columns, pk_name



# Open the immutable search index once. Searchers are created per request.
try:
    if not INDEX_PATH.is_dir():
        raise FileNotFoundError(f"پوشه ایندکس پیدا نشد: {INDEX_PATH}")
    SEARCH_INDEX = tantivy.Index.open(str(INDEX_PATH))
    SEARCH_INDEX.reload()
    INDEX_SEARCHER = SEARCH_INDEX.searcher()
    INDEX_DOC_COUNT = int(INDEX_SEARCHER.num_docs)
    INDEX_FIELDS = [f"C{i}" for i in range(2, 14)]
except Exception as _index_error:
    SEARCH_INDEX = None
    INDEX_SEARCHER = None
    INDEX_DOC_COUNT = 0
    INDEX_FIELDS = [f"C{i}" for i in range(2, 14)]
    INDEX_LOAD_ERROR = str(_index_error)
else:
    INDEX_LOAD_ERROR = ""



@lru_cache(maxsize=1)
def get_schema():
    with connect_readonly(DB_PATH) as conn:
        table, columns, pk = detect_main_table(conn)
    return table, columns, pk



@app.get("/")
def home():
    table, columns, pk = get_schema()
    return render_template("index.html", db_name=DB_PATH.name, table_name=table)



@app.get("/api/health")
def health():
    try:
        table, columns, pk = get_schema()
        if SEARCH_INDEX is None:
            return jsonify(ok=True, index_ready=False, error=INDEX_LOAD_ERROR,
                          database=DB_PATH.name, table=table, columns=columns, primary_key=pk,
                          count=0, labels=get_labels(columns)), 200
        # Index fields C2-C13 correspond to SQLite columns 2 through 13.
        field_map = [{"name": col, "index_field": f"C{i}"}
                    for i, col in enumerate(columns, start=1) if i >= 2]
        return jsonify(ok=True, index_ready=True, database=DB_PATH.name,
                      table=table, columns=columns, primary_key=pk,
                      fields=field_map, count=INDEX_DOC_COUNT, labels=get_labels(columns))
    except Exception as exc:
        return jsonify(ok=False, error=str(exc)), 500



@app.get("/api/search")
def search():
    query_text = (request.args.get("q") or "").strip()
    fuzzy = (request.args.get("fuzzy") or "0") == "1"
    try:
        page = max(1, min(int(request.args.get("page", "1")), 100000))
        page_size = max(10, min(int(request.args.get("per_page", str(DEFAULT_PAGE_SIZE))), MAX_PAGE_SIZE))
    except ValueError:
        page, page_size = 1, DEFAULT_PAGE_SIZE
    if SEARCH_INDEX is None:
        return jsonify(ok=False, error=f"ایندکس باز نشد: {INDEX_LOAD_ERROR}"), 503
    try:
        table, columns, pk = get_schema()
        filters = {c: (request.args.get("filter_" + c) or "").strip()
                   for c in columns if c != pk}
        filters = {k: v for k, v in filters.items() if v}
        offset = (page - 1) * page_size
        select_cols = ", ".join(quote_identifier(c) for c in columns)
        filter_sql = []
        filter_params = []
        for col, value in filters.items():
            filter_sql.append(f"instr(lower(coalesce({quote_identifier(col)}, '')), lower(?)) > 0")
            filter_params.append(value)
        filter_where = (" WHERE " + " AND ".join(filter_sql)) if filter_sql else ""

        if query_text and fuzzy:
            # Approximate matching is intentionally optional. Candidate rows are streamed
            # from SQLite; filters are applied in SQL before similarity scoring.
            score_rows = []
            scanned = 0
            capped = False
            with connect_readonly(DB_PATH) as conn:
                cur = conn.execute(f"SELECT {select_cols} FROM {quote_identifier(table)}{filter_where} ORDER BY {quote_identifier(pk)}", filter_params)
                for row in cur:
                    scanned += 1
                    if scanned > MAX_FUZZY_SCAN:
                        capped = True
                        break
                    values = [row[c] for c in columns[1:13]]
                    score = fuzzy_score(query_text, values)
                    if score > 0:
                        score_rows.append((score, dict(row)))
            score_rows.sort(key=lambda item: (-item[0], str(item[1].get(pk, ""))))
            total = len(score_rows)
            rows = [item[1] for item in score_rows[offset:offset + page_size]]
        else:
            where_clauses = list(filter_sql)
            params_sql = list(filter_params)
            if query_text:
                search_cols = columns[1:13]
                search_clause = " OR ".join(f"instr(lower(coalesce({quote_identifier(c)}, '')), lower(?)) > 0" for c in search_cols)
                where_clauses.insert(0, "(" + search_clause + ")")
                params_sql = [query_text] * len(search_cols) + params_sql
            where_sql = (" WHERE " + " AND ".join(where_clauses)) if where_clauses else ""
            with connect_readonly(DB_PATH) as conn:
                total = conn.execute(f"SELECT COUNT(*) FROM {quote_identifier(table)}{where_sql}", params_sql).fetchone()[0]
                fetched = conn.execute(f"SELECT {select_cols} FROM {quote_identifier(table)}{where_sql} ORDER BY {quote_identifier(pk)} LIMIT ? OFFSET ?", params_sql + [page_size, offset]).fetchall()
            rows = [dict(r) for r in fetched]
            capped = False
        pages = (total + page_size - 1) // page_size
        return jsonify(ok=True, query=query_text, fuzzy=fuzzy, total=total, page=page,
                      per_page=page_size, pages=pages, capped=capped,
                      max_search_hits=MAX_SEARCH_HITS if query_text else None,
                      columns=columns, primary_key=pk, rows=rows, filters=filters, labels=get_labels(columns))
    except Exception as exc:
        return jsonify(ok=False, error=f"جستجو ناموفق: {type(exc).__name__}: {exc}"), 400


@app.get("/api/row/<int:row_id>")
def row_detail(row_id):
    try:
        table, columns, pk = get_schema()
        select_cols = ", ".join(quote_identifier(c) for c in columns)
        sql = f"SELECT {select_cols} FROM {quote_identifier(table)} WHERE {quote_identifier(pk)}=? LIMIT 1"
        with connect_readonly(DB_PATH) as conn:
            row = conn.execute(sql, (row_id,)).fetchone()
        if row is None:
            return jsonify(ok=False, error="رکورد پیدا نشد."), 404
        return jsonify(ok=True, row=dict(row), columns=columns, primary_key=pk, labels=get_labels(columns))
    except Exception as exc:
        return jsonify(ok=False, error=str(exc)), 500



@app.errorhandler(404)
def not_found(_):
    return jsonify(ok=False, error="مسیر پیدا نشد."), 404



if __name__ == "__main__":
    print("=" * 56)
    print("LOCAL TANTIVY SEARCH")
    print(f"Database: {DB_PATH}")
    print(f"Index: {INDEX_PATH}")
    print(f"Listen: http://{HOST}:{PORT}")
    print("Source database is read-only; no index rebuild is performed.")
    print("=" * 56)
    app.run(host=HOST, port=PORT, debug=False, threaded=True)