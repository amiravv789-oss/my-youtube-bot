#!/usr/bin/env python3
"""Atlas read-only SQLite search. Does not create or modify database indexes."""
import os
import re
import sqlite3
import time
from contextlib import closing
from pathlib import Path
from flask import Flask, render_template, request, jsonify

BASE = Path(__file__).resolve().parent
DB_PATH = Path(os.environ.get("CUSTOMERS_DB", BASE / "users_merged.db")).resolve()
HOST = "127.0.0.1"
PORT = 8080
PER_PAGE_DEFAULT = 25
PER_PAGE_MAX = 100
QUERY_BUDGET_SECONDS = 12

FIELDS = {
    "national_code": "کد ملی", "full_name": "نام و نام خانوادگی",
    "father_name": "نام پدر", "birth_date": "تاریخ تولد",
    "birth_place": "محل تولد", "address": "آدرس", "city": "شهر",
    "province": "استان", "postal_code": "کد پستی", "mobile": "موبایل",
    "phone": "تلفن ثابت", "card": "شماره کارت / مقدار ذخیره‌شده",
}
TABLE_COLUMNS = tuple(FIELDS)
TEXT_COLUMNS = ("full_name", "father_name", "address", "city", "province", "birth_place")

app = Flask(__name__)
app.config["JSON_AS_ASCII"] = False
app.config["MAX_CONTENT_LENGTH"] = 1024 * 1024


def get_conn():
    if not DB_PATH.is_file():
        raise FileNotFoundError(f"Database not found: {DB_PATH}")
    # URI read-only plus query_only: Atlas cannot write to the source database.
    conn = sqlite3.connect(DB_PATH.as_uri() + "?mode=ro", uri=True, timeout=5)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA query_only=ON")
    conn.execute("PRAGMA busy_timeout=5000")
    # Stop exceptionally expensive scans instead of monopolising the DB for minutes.
    started = time.monotonic()
    conn.set_progress_handler(
        lambda: 1 if time.monotonic() - started > QUERY_BUDGET_SECONDS else 0,
        10000,
    )
    return conn


def ensure_schema(conn):
    cols = {r["name"] for r in conn.execute("PRAGMA table_info(users)").fetchall()}
    required = {"id", *TABLE_COLUMNS}
    missing = required - cols
    if missing:
        raise RuntimeError("ستون‌های موردنیاز در جدول users وجود ندارند: " + ", ".join(sorted(missing)))


def normalize_digits(value):
    return value.translate(str.maketrans("۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩", "01234567890123456789"))


def choose_search_columns(q):
    """Narrow obvious input types to their likely columns; no index is assumed."""
    compact = re.sub(r"[\s\-]+", "", normalize_digits(q))
    if compact.isdigit():
        if compact.startswith("09") and len(compact) <= 11:
            return ("mobile", "phone")
        if len(compact) == 16:
            return ("card",)
        if len(compact) == 10:
            return ("national_code",)
        # Partial numeric input: search plausible numeric fields only.
        return ("mobile", "phone", "national_code", "postal_code", "card")
    # Persian/Latin words are much more likely to be names or location/address.
    return TEXT_COLUMNS


def parse_page_size():
    try:
        n = int(request.args.get("per_page", str(PER_PAGE_DEFAULT)))
    except ValueError:
        n = PER_PAGE_DEFAULT
    return max(10, min(n, PER_PAGE_MAX))


@app.get("/")
def index():
    return render_template("index.html", db_name=DB_PATH.name)


@app.get("/api/health")
def health():
    try:
        with closing(get_conn()) as conn:
            ensure_schema(conn)
            # Deliberately do not COUNT(*) over tens of millions of rows at startup.
        return jsonify(ok=True, database=DB_PATH.name, count=None,
                       columns=["id", *TABLE_COLUMNS], labels={"id": "شناسه", **FIELDS},
                       read_only=True, indexes_created=False)
    except Exception as e:
        return jsonify(ok=False, error=str(e)), 500


@app.get("/api/search")
def search():
    q = (request.args.get("q") or "").strip()[:200]
    per_page = parse_page_size()
    try:
        cursor_id = request.args.get("after", "").strip()
        if cursor_id and not cursor_id.isdigit():
            return jsonify(ok=False, error="نشانگر صفحه نامعتبر است"), 400

        with closing(get_conn()) as conn:
            ensure_schema(conn)
            where, params = [], []
            if q:
                cols = choose_search_columns(q)
                where.append("(" + " OR ".join(f'CAST("{c}" AS TEXT) LIKE ?' for c in cols) + ")")
                normalized = normalize_digits(q)
                # Keep substring semantics for partial inputs, while avoiding scans of unrelated columns.
                where_params = [f"%{normalized}%"] * len(cols)
                params.extend(where_params)

            active_filters = {}
            for col in TABLE_COLUMNS:
                value = (request.args.get(col) or "").strip()[:200]
                if value:
                    where.append(f'CAST("{col}" AS TEXT) LIKE ?')
                    params.append(f"%{normalize_digits(value)}%")
                    active_filters[col] = value

            if cursor_id:
                where.append('"id" > ?')
                params.append(int(cursor_id))

            where_sql = (" WHERE " + " AND ".join(where)) if where else ""
            select_cols = ", ".join(['"id"'] + [f'"{c}"' for c in TABLE_COLUMNS])
            # Fetch one extra row to determine whether a next page exists; no expensive COUNT(*).
            rows = conn.execute(
                f'SELECT {select_cols} FROM users{where_sql} ORDER BY "id" LIMIT ?',
                params + [per_page + 1],
            ).fetchall()
            has_more = len(rows) > per_page
            rows = rows[:per_page]
            next_cursor = str(rows[-1]["id"]) if has_more and rows else None
            return jsonify(
                ok=True, total=None, returned=len(rows), has_more=has_more,
                next_cursor=next_cursor, rows=[dict(r) for r in rows],
                filters=active_filters, labels={"id": "شناسه", **FIELDS},
            )
    except sqlite3.OperationalError as e:
        msg = str(e).lower()
        if "interrupted" in msg:
            return jsonify(ok=False, error="جستجو بیش از حد طول کشید. عبارت را دقیق‌تر کنید یا فیلتر مشخص‌تری انتخاب کنید."), 408
        if "locked" in msg or "busy" in msg:
            return jsonify(ok=False, error="دیتابیس موقتاً مشغول نوشتن است؛ چند لحظه دیگر دوباره تلاش کنید."), 503
        return jsonify(ok=False, error=str(e)), 500
    except Exception as e:
        return jsonify(ok=False, error=str(e)), 500


@app.get("/api/row/<int:row_id>")
def row_detail(row_id):
    try:
        with closing(get_conn()) as conn:
            ensure_schema(conn)
            select_cols = ", ".join(['"id"'] + [f'"{c}"' for c in TABLE_COLUMNS])
            row = conn.execute(f'SELECT {select_cols} FROM users WHERE id=?', (row_id,)).fetchone()
            if row is None:
                return jsonify(ok=False, error="رکورد پیدا نشد"), 404
            return jsonify(ok=True, row=dict(row), labels={"id": "شناسه", **FIELDS})
    except Exception as e:
        return jsonify(ok=False, error=str(e)), 500


@app.errorhandler(404)
def not_found(_):
    return jsonify(ok=False, error="مسیر پیدا نشد"), 404


if __name__ == "__main__":
    print(f"Database (READ ONLY): {DB_PATH}")
    print(f"Local Search: http://{HOST}:{PORT}")
    if not DB_PATH.is_file():
        print("هشدار: فایل users_merged.db را کنار app.py قرار دهید.")
    app.run(host=HOST, port=PORT, debug=False, threaded=True)
