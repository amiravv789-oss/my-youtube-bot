#!/usr/bin/env python3
"""Atlas local Tantivy search. SQLite is strictly read-only."""
import os, sqlite3, re
from functools import lru_cache
from pathlib import Path
from flask import Flask, jsonify, render_template, request
import tantivy

BASE = Path(__file__).resolve().parent
DB_PATH = Path(os.environ.get('USERS_DB', str(Path.home() / 'Desktop' / 'users_merged.db'))).expanduser().resolve()
INDEX_PATH = Path(os.environ.get('USERS_SEARCH_INDEX', str(Path.home() / 'Desktop' / 'users_search_index'))).expanduser().resolve()
HOST = os.environ.get('LOCAL_SEARCH_HOST', '127.0.0.1')
PORT = int(os.environ.get('LOCAL_SEARCH_PORT', '8080'))
DEFAULT_PAGE_SIZE, MAX_PAGE_SIZE, MAX_SEARCH_HITS = 25, 100, 5000
app = Flask(__name__)
app.config['JSON_AS_ASCII'] = False
app.config['MAX_CONTENT_LENGTH'] = 1024 * 1024

FIELD_LABELS = {
    'id':'شناسه','national_code':'کد ملی','nationalcode':'کد ملی','full_name':'نام و نام خانوادگی','fullname':'نام و نام خانوادگی',
    'name':'نام و نام خانوادگی','first_name':'نام','firstname':'نام','last_name':'نام خانوادگی','lastname':'نام خانوادگی',
    'father_name':'نام پدر','birth_date':'تاریخ تولد','birthdate':'تاریخ تولد','birth_place':'محل تولد','birthplace':'محل تولد',
    'address':'آدرس','city':'شهر','province':'استان','postal_code':'کد پستی','postalcode':'کد پستی','mobile':'شماره موبایل','phone':'تلفن ثابت','card':'اطلاعات کارت'
}
POSITION_LABELS = ['شناسه','کد ملی','نام و نام خانوادگی','نام پدر','تاریخ تولد','محل تولد','آدرس','شهر','استان','کد پستی','شماره موبایل','تلفن ثابت','اطلاعات کارت']

def get_labels(columns):
    result = {}
    for i, col in enumerate(columns):
        norm = re.sub(r'[^a-z0-9]', '', str(col).lower())
        label = FIELD_LABELS.get(str(col).lower()) or FIELD_LABELS.get(norm)
        if not label and str(col).upper().startswith('C') and str(col)[1:].isdigit():
            label = POSITION_LABELS[i] if i < len(POSITION_LABELS) else f'اطلاعات {i+1}'
        result[col] = label or (POSITION_LABELS[i] if i < len(POSITION_LABELS) else f'اطلاعات {i+1}')
    return result

def connect_readonly(path):
    if not path.is_file():
        raise FileNotFoundError(f'فایل دیتابیس پیدا نشد: {path}')
    conn = sqlite3.connect(path.as_uri() + '?mode=ro', uri=True, timeout=30)
    conn.row_factory = sqlite3.Row
    conn.execute('PRAGMA query_only=ON')
    conn.execute('PRAGMA busy_timeout=30000')
    return conn

def quote_identifier(name):
    return '"' + str(name).replace('"', '""') + '"'

def detect_main_table(conn):
    candidates=[]
    for (name,) in conn.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'"):
        info=conn.execute(f'PRAGMA table_info({quote_identifier(name)})').fetchall()
        pks=[c for c in info if int(c[5])>0]
        if len(info)==13 and len(pks)==1 and str(pks[0][2]).upper()=='INTEGER':
            candidates.append((name,info,pks[0]))
    if len(candidates)!=1:
        raise RuntimeError(f'تشخیص جدول اصلی ناموفق؛ تعداد جدول‌های سازگار: {len(candidates)}')
    table,info,pk=candidates[0]
    columns=[c[1] for c in info]
    if columns.index(pk[1])!=0:
        raise RuntimeError('کلید اصلی در ستون اول نیست؛ ترتیب ایندکس با دیتابیس سازگار نیست.')
    return table,columns,pk[1]

try:
    if not INDEX_PATH.is_dir(): raise FileNotFoundError(f'پوشه ایندکس پیدا نشد: {INDEX_PATH}')
    SEARCH_INDEX=tantivy.Index.open(str(INDEX_PATH))
    SEARCH_INDEX.reload()
    INDEX_DOC_COUNT=int(SEARCH_INDEX.searcher().num_docs)
    INDEX_FIELDS=[f'C{i}' for i in range(2,14)]
    INDEX_LOAD_ERROR=''
except Exception as err:
    SEARCH_INDEX,INDEX_DOC_COUNT=None,0
    INDEX_FIELDS=[f'C{i}' for i in range(2,14)]
    INDEX_LOAD_ERROR=str(err)

@lru_cache(maxsize=1)
def get_schema():
    with connect_readonly(DB_PATH) as conn: return detect_main_table(conn)


def build_query(q, fuzzy):
    # Preserve the proven Tantivy query path from the old working version.
    safe=q.replace('"',' ').strip()
    if fuzzy:
        terms=[t for t in safe.split() if t]
        query_string=' AND '.join(f'{t}~1' for t in terms)
    else:
        query_string=f'"{safe}"'
    return SEARCH_INDEX.parse_query(query_string, INDEX_FIELDS)


def filter_sql_for(columns, pk, args):
    filters={c:(args.get('filter_'+c) or '').strip() for c in columns if c!=pk}
    filters={c:v for c,v in filters.items() if v}
    clauses=[f'instr(lower(coalesce({quote_identifier(c)}, "")), lower(?)) > 0' for c in filters]
    values=list(filters.values())
    return filters, clauses, values


@app.get('/')
def home():
    table,columns,pk=get_schema()
    return render_template('index.html',db_name=DB_PATH.name,table_name=table)


@app.get('/api/health')
def health():
    try:
        table,columns,pk=get_schema()
        fields=[{'name':c,'index_field':f'C{i}'} for i,c in enumerate(columns,start=1) if i>=2]
        return jsonify(ok=True,index_ready=SEARCH_INDEX is not None,error=INDEX_LOAD_ERROR if SEARCH_INDEX is None else '',database=DB_PATH.name,table=table,columns=columns,primary_key=pk,count=INDEX_DOC_COUNT,fields=fields,labels=get_labels(columns))
    except Exception as exc: return jsonify(ok=False,error=str(exc)),500


@app.get('/api/search')
def search():
    q=(request.args.get('q') or '').strip()
    fuzzy=request.args.get('fuzzy','0')=='1'
    try:
        page=max(1,min(int(request.args.get('page','1')),100000))
        per_page=max(10,min(int(request.args.get('per_page',str(DEFAULT_PAGE_SIZE))),MAX_PAGE_SIZE))
    except ValueError: page,per_page=1,DEFAULT_PAGE_SIZE
    if SEARCH_INDEX is None: return jsonify(ok=False,error=f'ایندکس باز نشد: {INDEX_LOAD_ERROR}'),503
    try:
        table,columns,pk=get_schema(); offset=(page-1)*per_page
        filters,filter_clauses,filter_values=filter_sql_for(columns,pk,request.args)
        select_cols=', '.join(quote_identifier(c) for c in columns)
        where_filter=(' WHERE '+' AND '.join(filter_clauses)) if filter_clauses else ''
        if q:
            searcher=SEARCH_INDEX.searcher()
            result=searcher.search(build_query(q,fuzzy),limit=MAX_SEARCH_HITS)
            total_index=int(result.count)
            hits=result.hits[:MAX_SEARCH_HITS]
            ids=[]
            for _,addr in hits:
                doc=searcher.doc(addr)
                rid=doc.get_first('rid')
                if rid is not None: ids.append(int(rid))
            rows_by_id={}
            if ids:
                # Batch safely below SQLite's parameter limit.
                with connect_readonly(DB_PATH) as conn:
                    for start in range(0,len(ids),800):
                        batch=ids[start:start+800]
                        marks=','.join('?' for _ in batch)
                        sql=f'SELECT {select_cols} FROM {quote_identifier(table)} WHERE {quote_identifier(pk)} IN ({marks})'
                        fetched=conn.execute(sql,batch).fetchall()
                        rows_by_id.update({int(r[pk]):dict(r) for r in fetched})
            ordered=[rows_by_id[rid] for rid in ids if rid in rows_by_id]
            if filters:
                def passes(row):
                    return all(value.casefold() in str(row.get(col) or '').casefold() for col,value in filters.items())
                ordered=[r for r in ordered if passes(r)]
                total=len(ordered)
                rows=ordered[offset:offset+per_page]
                capped=total_index>MAX_SEARCH_HITS
            else:
                total=total_index
                rows=ordered[offset:offset+per_page]
                capped=total_index>MAX_SEARCH_HITS
            pages=min((total+per_page-1)//per_page,(MAX_SEARCH_HITS+per_page-1)//per_page)
        else:
            where_sql=where_filter
            with connect_readonly(DB_PATH) as conn:
                total=conn.execute(f'SELECT COUNT(*) FROM {quote_identifier(table)}{where_sql}',filter_values).fetchone()[0]
                fetched=conn.execute(f'SELECT {select_cols} FROM {quote_identifier(table)}{where_sql} ORDER BY {quote_identifier(pk)} LIMIT ? OFFSET ?',filter_values+[per_page,offset]).fetchall()
            rows=[dict(r) for r in fetched]
            pages=(total+per_page-1)//per_page
            capped=False
        return jsonify(ok=True,query=q,fuzzy=fuzzy,total=total,page=page,per_page=per_page,pages=pages,capped=capped,max_search_hits=MAX_SEARCH_HITS if q else None,columns=columns,primary_key=pk,rows=rows,filters=filters,labels=get_labels(columns))
    except Exception as exc:
        return jsonify(ok=False,error=f'جستجو ناموفق: {type(exc).__name__}: {exc}'),400

@app.get('/api/row/<int:row_id>')
def row_detail(row_id):
    try:
        table,columns,pk=get_schema(); select_cols=', '.join(quote_identifier(c) for c in columns)
        with connect_readonly(DB_PATH) as conn: row=conn.execute(f'SELECT {select_cols} FROM {quote_identifier(table)} WHERE {quote_identifier(pk)}=? LIMIT 1',(row_id,)).fetchone()
        if row is None: return jsonify(ok=False,error='رکورد پیدا نشد.'),404
        return jsonify(ok=True,row=dict(row),columns=columns,primary_key=pk,labels=get_labels(columns))
    except Exception as exc: return jsonify(ok=False,error=str(exc)),500

@app.errorhandler(404)
def not_found(_): return jsonify(ok=False,error='مسیر پیدا نشد.'),404


if __name__=='__main__':
    print(f'Atlas Tantivy local search · Database: {DB_PATH} · Index: {INDEX_PATH} · http://{HOST}:{PORT}')
    app.run(host=HOST,port=PORT,debug=False,threaded=True)
