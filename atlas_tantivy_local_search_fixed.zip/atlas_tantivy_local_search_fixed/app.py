#!/usr/bin/env python3
"""Local SQLite/Tantivy search. Source SQLite is opened strictly read-only."""
import os
import re
import sqlite3
from functools import lru_cache
from pathlib import Path
from flask import Flask, jsonify, render_template, request
import tantivy

BASE = Path(__file__).resolve().parent
DB_PATH = Path(os.environ.get("USERS_DB", str(Path.home() / "Desktop" / "users_merged.db"))).expanduser().resolve()
INDEX_PATH = Path(os.environ.get("USERS_SEARCH_INDEX", str(Path.home() / "Desktop" / "users_search_index"))).expanduser().resolve()
HOST = os.environ.get("LOCAL_SEARCH_HOST", "127.0.0.1")
PORT = int(os.environ.get("LOCAL_SEARCH_PORT", "8080"))
DEFAULT_PAGE_SIZE = 25
MAX_PAGE_SIZE = 100
MAX_SEARCH_HITS = 5000

app = Flask(__name__)
app.config["JSON_AS_ASCII"] = False
app.config["MAX_CONTENT_LENGTH"] = 1024 * 1024



def connect_readonly(path: Path):
    if not path.is_file():
        raise FileNotFoundError(f"فایل دیتابیس پیدا نشد: {path}")
    conn = sqlite3.connect(path.as_uri() + "?mode=ro", uri=True, timeout=30)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA query_only=ON")
    conn.execute("PRAGMA busy_timeout=30000")
    return conn



def quote_identifier(name: str) -> str:
    return '"' + str(name).replace('"', '""') + '"'



def detect_main_table(conn):
    candidates = []
    for (name,) in conn.execute(
        "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'"
    ):
        info = conn.execute(f"PRAGMA table_info({quote_identifier(name)})").fetchall()
        if len(info) != 13:
            continue
        pk_cols = [c for c in info if int(c[5]) > 0]
        if len(pk_cols) == 1 and str(pk_cols[0][2]).upper() == "INTEGER":
            candidates.append((name, info, pk_cols[0]))
    if len(candidates) != 1:
        raise RuntimeError(f"تشخیص جدول اصلی ناموفق بود؛ تعداد جدول‌های سازگار: {len(candidates)}")
    table, info, pk = candidates[0]
    columns = [c[1] for c in info]
    pk_name = pk[1]
    if columns.index(pk_name) != 0:
        # The search-index build stored the source row's first column as rid.
        # A primary key outside column 1 would not match that index mapping.
        raise RuntimeError("کلید اصلی در ستون اول جدول نیست؛ ترتیب ایندکس با دیتابیس سازگار نیست.")
    return table, columns, pk_name


def build_basic_query(index, text, field_names):
    """Build an OR query from single-token queries; basic indexes have no positions."""
    tokens = list(dict.fromkeys(re.findall(r"\w+", text, flags=re.UNICODE)))
    if not tokens:
        return None
    token_queries = [index.parse_query(token, field_names) for token in tokens[:16]]
    if len(token_queries) == 1:
        return token_queries[0]
    return tantivy.Query.boolean_query([
        (tantivy.Occur.Should, query) for query in token_queries
    ])



# Open the immutable search index once. Searchers are created per request.
try:
    if not INDEX_PATH.is_dir():
        raise FileNotFoundError(f"پوشه ایندکس پیدا نشد: {INDEX_PATH}")
    SEARCH_INDEX = tantivy.Index.open(str(INDEX_PATH))
    SEARCH_INDEX.reload()
    INDEX_SEARCHER = SEARCH_INDEX.searcher()
    INDEX_DOC_COUNT = int(INDEX_SEARCHER.num_docs)
    INDEX_FIELDS = [f"C{i}" for i in range(2, 14)]
except Exception as _index_error:
    SEARCH_INDEX = None
    INDEX_SEARCHER = None
    INDEX_DOC_COUNT = 0
    INDEX_FIELDS = [f"C{i}" for i in range(2, 14)]
    INDEX_LOAD_ERROR = str(_index_error)
else:
    INDEX_LOAD_ERROR = ""



@lru_cache(maxsize=1)
def get_schema():
    with connect_readonly(DB_PATH) as conn:
        table, columns, pk = detect_main_table(conn)
    return table, columns, pk



@app.get("/")
def home():
    table, columns, pk = get_schema()
    return render_template("index.html", db_name=DB_PATH.name, table_name=table)



@app.get("/api/health")
def health():
    try:
        table, columns, pk = get_schema()
        if SEARCH_INDEX is None:
            return jsonify(ok=True, index_ready=False, error=INDEX_LOAD_ERROR,
                          database=DB_PATH.name, table=table, columns=columns, primary_key=pk,
                          count=0), 200
        # Index fields C2-C13 correspond to SQLite columns 2 through 13.
        field_map = [{"name": col, "index_field": f"C{i}"}
                    for i, col in enumerate(columns, start=1) if i >= 2]
        return jsonify(ok=True, index_ready=True, database=DB_PATH.name,
                      table=table, columns=columns, primary_key=pk,
                      fields=field_map, count=INDEX_DOC_COUNT)
    except Exception as exc:
        return jsonify(ok=False, error=str(exc)), 500



@app.get("/api/search")
def search():
    query_text = (request.args.get("q") or "").strip()
    try:
        page = max(1, min(int(request.args.get("page", "1")), 100000))
        page_size = max(10, min(int(request.args.get("per_page", str(DEFAULT_PAGE_SIZE))), MAX_PAGE_SIZE))
    except ValueError:
        page, page_size = 1, DEFAULT_PAGE_SIZE


    if SEARCH_INDEX is None:
        return jsonify(ok=False, error=f"ایندکس باز نشد: {INDEX_LOAD_ERROR}"), 503

    try:
        table, columns, pk = get_schema()
        offset = (page - 1) * page_size
        rows = []

        if query_text:
            # Tantivy index has the integer rid and searchable C2..C13 fields.
            # The index was built with index_option="basic" (no token positions).
            # Parse each token separately and combine them with OR to avoid phrase queries.
            query = build_basic_query(SEARCH_INDEX, query_text, INDEX_FIELDS)
            if query is None:
                return jsonify(ok=True, query=query_text, total=0, page=page,
                              per_page=page_size, pages=1, capped=False,
                              columns=columns, primary_key=pk, rows=[])
            searcher = SEARCH_INDEX.searcher()
            cap = min(offset + page_size, MAX_SEARCH_HITS)
            result = searcher.search(query, limit=cap)
            total = int(result.count)
            hits = result.hits[offset:offset + page_size] if offset < MAX_SEARCH_HITS else []
            ids = []
            for score, address in hits:
                doc = searcher.doc(address)
                rid = doc.get_first("rid")
                if rid is not None:
                    ids.append(int(rid))
            if ids:
                marks = ",".join("?" for _ in ids)
                select_cols = ", ".join(quote_identifier(c) for c in columns)
                sql = (f"SELECT {select_cols} FROM {quote_identifier(table)} "
                       f"WHERE {quote_identifier(pk)} IN ({marks})")
                with connect_readonly(DB_PATH) as conn:
                    fetched = conn.execute(sql, ids).fetchall()
                by_id = {int(r[pk]): dict(r) for r in fetched}
                rows = [by_id[rid] for rid in ids if rid in by_id]
            pages = min((total + page_size - 1) // page_size,
                        (MAX_SEARCH_HITS + page_size - 1) // page_size)
            capped = total > MAX_SEARCH_HITS
        else:
            total = INDEX_DOC_COUNT
            pages = (total + page_size - 1) // page_size
            capped = False
            select_cols = ", ".join(quote_identifier(c) for c in columns)
            sql = (f"SELECT {select_cols} FROM {quote_identifier(table)} "
                   f"ORDER BY {quote_identifier(pk)} LIMIT ? OFFSET ?")
            with connect_readonly(DB_PATH) as conn:
                fetched = conn.execute(sql, (page_size, offset)).fetchall()
            rows = [dict(r) for r in fetched]

        return jsonify(ok=True, query=query_text, total=total, page=page,
                      per_page=page_size, pages=pages, capped=capped,
                      max_search_hits=MAX_SEARCH_HITS if query_text else None,
                      columns=columns, primary_key=pk, rows=rows)
    except Exception as exc:
        return jsonify(ok=False, error=f"جستجو ناموفق: {type(exc).__name__}: {exc}"), 400



@app.get("/api/row/<int:row_id>")
def row_detail(row_id):
    try:
        table, columns, pk = get_schema()
        select_cols = ", ".join(quote_identifier(c) for c in columns)
        sql = f"SELECT {select_cols} FROM {quote_identifier(table)} WHERE {quote_identifier(pk)}=? LIMIT 1"
        with connect_readonly(DB_PATH) as conn:
            row = conn.execute(sql, (row_id,)).fetchone()
        if row is None:
            return jsonify(ok=False, error="رکورد پیدا نشد."), 404
        return jsonify(ok=True, row=dict(row), columns=columns, primary_key=pk)
    except Exception as exc:
        return jsonify(ok=False, error=str(exc)), 500



@app.errorhandler(404)
def not_found(_):
    return jsonify(ok=False, error="مسیر پیدا نشد."), 404



if __name__ == "__main__":
    print("=" * 56)
    print("LOCAL TANTIVY SEARCH")
    print(f"Database: {DB_PATH}")
    print(f"Index: {INDEX_PATH}")
    print(f"Listen: http://{HOST}:{PORT}")
    print("Source database is read-only; no index rebuild is performed.")
    print("=" * 56)
    app.run(host=HOST, port=PORT, debug=False, threaded=True)
